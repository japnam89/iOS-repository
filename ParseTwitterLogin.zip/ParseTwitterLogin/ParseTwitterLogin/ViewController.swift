//
//  ViewController.swift
//  ParseTwitterLogin
//
//  Created by JAPNAM SINGH on 7/14/15.
//  Copyright (c) 2015 JAPNAM SINGH. All rights reserved.
//

import UIKit
import Parse
import ParseUI


class ViewController: UIViewController,PFLogInViewControllerDelegate,PFSignUpViewControllerDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
       self.loginSetup()
    }

    
    func logInViewController(logInController: PFLogInViewController, shouldBeginLogInWithUsername username: String, password: String) -> Bool {
        if(!username.isEmpty || !password.isEmpty ){
            
            return true
        }else{
            return false
        }
    }
    
    
    
    func logInViewController(logInController: PFLogInViewController, didLogInUser user: PFUser) {
        if(PFTwitterUtils.isLinkedWithUser(user)){
            
            var twitterUsername = PFTwitterUtils.twitter()?.screenName
            PFUser.currentUser()?.username = twitterUsername
            PFUser.currentUser()?.saveEventually(nil)
        }
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func signUpViewController(signUpController: PFSignUpViewController, didFailToSignUpWithError error: NSError?) {
        println("Failed to sign up")
    }
    
    
    func signUpViewControllerDidCancelSignUp(signUpController: PFSignUpViewController) {
     println("User dismissed sign up")
    }
    
    @IBAction func logoutAction(sender: AnyObject) {
        
        PFUser.logOut()
        self.loginSetup()
    }
    
    func loginSetup(){
        
        if(PFUser.currentUser()==nil){
            
            var logInViewController = PFLogInViewController()
            logInViewController.delegate = self
            logInViewController.fields = PFLogInFields.UsernameAndPassword | PFLogInFields.LogInButton | PFLogInFields.SignUpButton | PFLogInFields.PasswordForgotten | PFLogInFields.Twitter
            var signUpViewController=PFSignUpViewController()
            signUpViewController.delegate = self
            logInViewController.signUpController = signUpViewController
            self.presentViewController(logInViewController,animated:true,completion:nil)
            
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

